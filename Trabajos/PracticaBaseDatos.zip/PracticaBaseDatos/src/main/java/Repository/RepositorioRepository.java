package Repository;

public class RepositorioRepository {
}

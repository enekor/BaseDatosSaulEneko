package Repository;

public class IssueRepository {
}

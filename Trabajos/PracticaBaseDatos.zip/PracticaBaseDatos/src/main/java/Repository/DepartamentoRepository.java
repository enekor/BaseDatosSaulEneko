package Repository;

public class DepartamentoRepository {
}

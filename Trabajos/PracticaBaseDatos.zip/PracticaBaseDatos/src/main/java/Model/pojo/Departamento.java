package Model.pojo;

import lombok.Data;

@Data
public class Departamento {
    private String id;
    private String nombre;
    private String id_jefe;
    private double presupuesto;



}

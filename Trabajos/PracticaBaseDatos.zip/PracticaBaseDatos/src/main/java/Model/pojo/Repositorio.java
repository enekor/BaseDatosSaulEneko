package Model.pojo;

import lombok.Data;

@Data
public class Repositorio {
    private String id;
    private String nombre;
    private String fecha;
    private String id_proyecto;
}
